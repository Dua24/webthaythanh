<?php
include '../controller/productController.php';
$product = new Product_Controller();
$product->invoke();
