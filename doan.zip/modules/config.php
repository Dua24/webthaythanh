<?php
define("HOST", "localhost");
define("DB", "db_hfwth");
define("USER", "root");
define("PASSWORD", "");
