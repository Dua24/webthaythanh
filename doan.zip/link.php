<?php
include_once "modules/db_module.php";

$link = null;
taoKetNoi($link);

?>